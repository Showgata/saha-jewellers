
        $(function () {
        	 $("#mortgage_detail").dataTable();
        	 $("#loan-give").dataTable();
        	 $("#loan-take").dataTable();
        });
       